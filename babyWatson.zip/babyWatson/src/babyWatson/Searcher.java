package babyWatson;
/*_____________________________________________________________________________
Class: Searcher
Purpose: This class opens an existing Lucene index. It parses user queries 
		using a unigram analyzer and then searches across two fields: 
		content_unigram and content_bigram. It then boosts bigram matches
		and returns the top-ranked document for a given clue.
				
Fields:
		searcher -> an IndexSearcher that executes Lucene queries against
				the index
		parser -> a MultiFieldQueryParser that converts a text query into
				a Lucene Query object

Functions:
		Searcher()
		searchTopDoc()
		main()
		
Dependencies: Requires an existing Lucene index of wikipedia files.
		
This Class can take a couple of seconds to run.
NOTE: In the terminal, there is a red-text Warning. This is normal. The program 
	will still run.
 ____________________________________________________________________________
*/

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.index.DirectoryReader;
import org.apache.lucene.queryparser.classic.MultiFieldQueryParser;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.ScoreDoc;
import org.apache.lucene.search.TopDocs;
import org.apache.lucene.store.FSDirectory;

import java.io.BufferedReader;
import java.io.FileReader;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;

public class Searcher {

    private final IndexSearcher searcher;
    private final MultiFieldQueryParser parser;

    /*
    Function: Searcher()
    Parameters: indexDir, a string path to the Lucene index directory
    Purpose: Initializes the search engine by opening the Lucene index 
    		directory, creating an IndexSearcher, and creating a 
    		MultiFieldQueryParser that searches both unigram and bigram 
    		fields.
    */
    public Searcher(String indexDir) throws Exception {
        Path indexPath = Paths.get(indexDir);
        DirectoryReader reader = DirectoryReader.open(FSDirectory.open(indexPath));
        searcher = new IndexSearcher(reader);

        // Use unigram analyzer for parsing queries
        Analyzer unigramAnalyzer = new StandardAnalyzer();

        // Boost bigram matches
        String[] fields = { "content_unigram", "content_bigram" };
        Map<String,Float> boosts = new HashMap<>();
        boosts.put("content_unigram", 1.0f);
        boosts.put("content_bigram", 1.4f);

        parser = new MultiFieldQueryParser(fields, unigramAnalyzer, boosts);
    }

    /*
    Function: searchTopDoc()
    Parameters: clue, a String holding a natural language question or phrase
    Returns: A Lucene Document representing the top search result, or null
    		if no results are found.
    Purpose: Searches the index for the single best-matching document for a 
    		given clue.
    */
    public Document searchTopDoc(String clue) throws Exception {
        Query query = parser.parse(clue);
        TopDocs results = searcher.search(query, 1);

        if (results.scoreDocs.length == 0) {
            return null;
        }
        ScoreDoc sd = results.scoreDocs[0];
        Document d = searcher.storedFields().document(sd.doc);
        return d;
    }
    
    /*
    Function: main()
    Purpose: Reads a file of Jeopardy-style questions and evaluates how often
    		the searcher retrieves the correct answer. 
    		
    		questions.txt must be in the format:
    		1. Category
    		2. Clue
    		3. Answer
    		4. Blank line
    */
    public static void main(String[] args) throws Exception {
    	Searcher s = new Searcher("wiki_index");  // <-- your index path
        try (BufferedReader br = new BufferedReader(new FileReader("questions.txt"))) {

            int count = 0;
            int total = 0;
            int noneCount = 0;
            String category;

            while ((category = br.readLine()) != null) {
            	total++;

                String clue = br.readLine();     // second line
                clue = clue.replaceAll("[^A-Za-z0-9 ]", " ");
                clue = clue.replaceAll("\\s+", " ").trim();

                String answer = br.readLine();   // third line
                br.readLine();                   // blank line separator

                /*
                System.out.println("====================================");
                System.out.println("CATEGORY: " + category);
                System.out.println("CLUE: " + clue);
                System.out.println("ANSWER (gold): " + answer);*/

                Document top = s.searchTopDoc(clue);

                if (top == null) {
                    //System.out.println("TOP DOC: <none>");
                    noneCount++;
                } else {
                    String predicted = top.get("title");
                    //System.out.println("TOP DOC: " + predicted);

                    if (predicted != null && predicted.equalsIgnoreCase(answer)) {
                        count++;
                    }
                }
            }

            System.out.println("Answers Matched: " + count);
            System.out.println("Total Questions: " + total);
            //System.out.println("No Answers Found: " + noneCount);
        }
    }
}
