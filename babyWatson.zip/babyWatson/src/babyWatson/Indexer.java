package babyWatson;
/*_____________________________________________________________________________
  Class: Indexer
  Purpose: A class that, when run, indexes a Wikipedia corpus using Apache
  		Lucene. The indexer:
  			- Walks through all files in a directory
			- Splits each file into individual pages
			- Detects redirects
			- Builds alias lists (redirects → target)
			- Indexes each page with:
				- Unigram text field
				- Bigram text field
				- Title and expanded title
				- Document ID
				
 Fields:
 		indexPath -> where the Lucene index gets stored
 		unigramAnalyzer -> standard Lucene analyzer
 		bigramAnalyzer -> custom analyzer
 		redirectMap -> stores redirect relationships ("USA" -> "United States")
 		
 Functions:
 		Indexer()
 		indexCorpus()
 		indexMultiPageFile()
 		getRedirectTarget()
 		indexSinglePage()
 		main()
 		
 Dependencies: Requires BigramAnalyzer.java to run. Also requires the pom.xml
 		file included in the project folder to run Lucene.
 		
 		
 When run, this Class creates a folder, wiki-index. 
 NOTE: This program can take multiple minutes to run! Also, in the terminal, 
 		there is a red-text Warning. This is normal. The program will still
 		run.
   ____________________________________________________________________________
 */

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.document.*;
import org.apache.lucene.index.*;
import org.apache.lucene.store.*;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.ArrayList;
import java.util.List;
import java.util.HashMap;
import java.util.Map;

public class Indexer {

    private final Path indexPath;
    private final Analyzer unigramAnalyzer = new StandardAnalyzer();
    private final Analyzer bigramAnalyzer = new BigramAnalyzer();
    private Map<String, String> redirectMap = new HashMap<>();
    
    public Indexer(String indexDir) {
        this.indexPath = Paths.get(indexDir);
    }

    /*
     Function: indexCorpus()
     Parameters: corpusDir, a path object directing to a folder of wiki docs
     Returns: None
     Purpose: The top-level driver of this class. Opens the index directory and
     		creates an IndexWriter with the unigram analyzer. Then it walks the
     		entire corpus directory. Uses indexMultiPageFile as a helper function
     		to delegate parsing
     */
    public void indexCorpus(Path corpusDir) throws Exception {
    	// open the directory of wiki docs
        Directory dir = FSDirectory.open(indexPath);

        IndexWriterConfig config = new IndexWriterConfig(unigramAnalyzer);
        config.setOpenMode(IndexWriterConfig.OpenMode.CREATE);

        // for each file, call indexMultiPageFile
        try (IndexWriter writer = new IndexWriter(dir, config)) {
            Files.walk(corpusDir)
                .filter(Files::isRegularFile)
                .forEach(path -> {
                    try {
                        indexMultiPageFile(writer, path);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                });
        }
    }

    /*
    Function: indexMultiPageFile()
    Parameters: writer, an IndexWriter object that Lucene uses to add documents
    			file, a Path Object that points to a wikipedia file
    Returns: None
    Purpose: Splits a file into pages. Each wiki file contains thousands of
    		wiki pages. Each page begins with a title line like [[TITLE]].
    		For each line, this function detects title lines and accumulates 
    		text until the next title. Once a new title is found, the previous
    		page gets indexed.
    */
    private void indexMultiPageFile(IndexWriter writer, Path file) throws Exception {
        try (BufferedReader reader = Files.newBufferedReader(file, StandardCharsets.ISO_8859_1)) {

            String line;
            StringBuilder pageBuffer = new StringBuilder();
            String currentTitle = null;

            while ((line = reader.readLine()) != null) {

                // Detect start of a new page: [[TITLE]]
                if (line.startsWith("[[") && line.endsWith("]]")) {

                    // If we already collected a page, index it
                    if (currentTitle != null && pageBuffer.length() > 0) {
                        indexSinglePage(writer, currentTitle, pageBuffer.toString(), file);
                    }

                    // Start new page
                    currentTitle = line.substring(2, line.length() - 2).trim();
                    pageBuffer.setLength(0); // clear buffer
                } else {
                    // Accumulate page content
                    pageBuffer.append(line).append('\n');
                }
            }

            // Index last page in file
            if (currentTitle != null && pageBuffer.length() > 0) {
                indexSinglePage(writer, currentTitle, pageBuffer.toString(), file);
            }
        }
    }


    /*
    Function: getRedirectTarget()
    Parameters: text, a String containing the full text of a wiki page
    Returns: a String holding the title of the page being redirected to, 
    		or null otherwise.
    Purpose: Detects whether a page is a redirect, then extracts the redirect
    		target. Converts the text to lowercase and checks if text starts
    		with #redirect. If so, extracts the target inside [[...]]]
    			ex: #REDIRECT [[United States]]
    				returns "United States"
    */ 
    private String getRedirectTarget(String text) {
    	String lower = text.toLowerCase();

        if (lower.startsWith("#redirect")) {
            int start = text.indexOf("[[");
            int end = text.indexOf("]]");

            if (start != -1 && end != -1 && end > start) {
                return text.substring(start + 2, end).trim();
            }
        }
        return null;
    }
    
    /*
    Function: indexSinglePage()
    Parameters: writer, an IndexWriter that Lucene uses to add the document
    			title, a String holding the title extracted from the page
    			text, a String holding the full text of the page
    			file, a Path holding the file the page came from
    Returns: None
    Purpose: Indexes one Wikipedia page as a Lucene doc. Detects redirects and
    			collects aliases, storing them into an expanded title. Then a
    			Lucene document gets built. Finally, document gets added to
    			the index.
    */ 
    private void indexSinglePage(IndexWriter writer, String title, String text, Path file) throws Exception {
    	// 1. Detect redirect
    	String redirectTarget = getRedirectTarget(text);
	
	    if (redirectTarget != null) {
	        // Store redirect mapping
	        redirectMap.put(title, redirectTarget);
	        return; // Do NOT index redirect pages
	    }
	
	    // 2. Collect all aliases (redirects pointing to this page)
	    List<String> aliases = new ArrayList<>();
	    for (Map.Entry<String, String> e : redirectMap.entrySet()) {
	        if (e.getValue().equals(title)) {
	            aliases.add(e.getKey());
	        }
	    }
	
	    // 3. Build expanded title field
	    StringBuilder expandedTitle = new StringBuilder(title);
	    for (String alias : aliases) {
	        expandedTitle.append(" ").append(alias);
	    }
	    
        // Extract first 3 paragraphs (much better for Jeopardy)
        //String shortText = extractFirstParagraphs(text, 3);
    	String fullText = text;
        Document doc = new Document();

        doc.add(new StoredField("title", title));
        // Store expanded title for searching
        doc.add(new TextField("title_text", expandedTitle.toString(), Field.Store.NO));
        doc.add(new StringField("doc_id", file.getFileName().toString(), Field.Store.YES));

        // Unigram field
        doc.add(new TextField("content_unigram", fullText, Field.Store.NO));

        // Bigram field
        FieldType bigramType = new FieldType(TextField.TYPE_NOT_STORED);
        bigramType.setStoreTermVectors(true);
        doc.add(new Field("content_bigram",
                bigramAnalyzer.tokenStream("content_bigram", fullText),
                bigramType));

        writer.addDocument(doc);
    }



    public static void main(String[] args) throws Exception {
    	long start = System.currentTimeMillis();

        Indexer indexer = new Indexer("wiki_index");
        indexer.indexCorpus(Paths.get("wiki-subset-20140602"));

        long end = System.currentTimeMillis();

        long elapsedMs = end - start;
        double elapsedSec = elapsedMs / 1000.0;
        double elapsedMin = elapsedSec / 60.0;

        System.out.println("Finished Indexing!");
        System.out.println("Time: " + elapsedSec + " seconds");
        System.out.println("Time: " + elapsedMin + " minutes");
    	
    }
}
